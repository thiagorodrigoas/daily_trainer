# Daily Trainer
Projeto backend em FastAPI com DuckDB.