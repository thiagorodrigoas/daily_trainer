from fastapi import FastAPI

from app.core.config import get_settings
from app.core.db import init_db
from app.api.v1 import alunos as alunos_router

settings = get_settings()

app = FastAPI(title=settings.app_name)

@app.on_event("startup")
def on_startup():
    init_db()

@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "environment": settings.environment,
        "app": settings.app_name,
    }

app.include_router(alunos_router.router)
