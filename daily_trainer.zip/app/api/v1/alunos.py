from typing import List
from fastapi import APIRouter, Depends, HTTPException, status
from app.core.db import get_cursor
from app.models.aluno import Aluno

router = APIRouter(prefix="/alunos", tags=["alunos"])

def get_db_cursor():
    with get_cursor() as cursor:
        yield cursor

@router.post('/', response_model=Aluno, status_code=status.HTTP_201_CREATED)
def criar_aluno(aluno: Aluno, cursor=Depends(get_db_cursor)):
    cursor.execute(
        '''
        INSERT INTO alunos (nome, telefone, observacoes)
        VALUES (?, ?, ?)
        RETURNING id;
        ''',
        [aluno.nome, aluno.telefone, aluno.observacoes]
    )
    new_id = cursor.fetchone()[0]
    return Aluno(id=new_id, **aluno.model_dump(exclude={"id"}))

@router.get('/', response_model=List[Aluno])
def listar_alunos(cursor=Depends(get_db_cursor)):
    cursor.execute('SELECT id, nome, telefone, observacoes FROM alunos ORDER BY id;')
    rows = cursor.fetchall()
    return [Aluno(id=r[0], nome=r[1], telefone=r[2], observacoes=r[3]) for r in rows]

@router.get('/{aluno_id}', response_model=Aluno)
def obter_aluno(aluno_id: int, cursor=Depends(get_db_cursor)):
    cursor.execute('SELECT id, nome, telefone, observacoes FROM alunos WHERE id = ?;', [aluno_id])
    row = cursor.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail='Aluno não encontrado')
    return Aluno(id=row[0], nome=row[1], telefone=row[2], observacoes=row[3])

@router.delete('/{aluno_id}', status_code=status.HTTP_204_NO_CONTENT)
def deletar_aluno(aluno_id: int, cursor=Depends(get_db_cursor)):
    cursor.execute('DELETE FROM alunos WHERE id = ?;', [aluno_id])
    return
