from contextlib import contextmanager
from pathlib import Path
import duckdb
from .config import get_settings

settings = get_settings()
DB_PATH: Path = settings.duckdb_path
DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def init_db():
    conn = duckdb.connect(str(DB_PATH))
    cursor = conn.cursor()
    cursor.execute(
        '''
        CREATE TABLE IF NOT EXISTS alunos (
            id INTEGER NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
            nome TEXT NOT NULL,
            telefone TEXT,
            observacoes TEXT
        );
        '''
    )
    conn.commit()
    conn.close()

@contextmanager
def get_cursor():
    conn = duckdb.connect(str(DB_PATH))
    try:
        cursor = conn.cursor()
        yield cursor
        conn.commit()
    finally:
        conn.close()
