from typing import Optional
from pydantic import BaseModel, Field

class Aluno(BaseModel):
    id: Optional[int] = None
    nome: str = Field(..., min_length=1)
    telefone: Optional[str] = None
    observacoes: Optional[str] = None
