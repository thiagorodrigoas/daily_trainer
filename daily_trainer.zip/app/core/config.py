from pydantic import BaseModel
from functools import lru_cache
from pathlib import Path
import os

class Settings(BaseModel):
    app_name: str = "Daily Trainer"
    environment: str = os.getenv("ENVIRONMENT", "dev")
    duckdb_path: Path = Path(os.getenv("DUCKDB_PATH", "app/db/data/daily_trainer.duckdb"))

@lru_cache
def get_settings() -> Settings:
    return Settings()
